#include <stdio.h>
int main() {

int c=0, v[4];


for (c=0;c<=4;c++) {
	printf("\nDigite o %d valor para v1 :",c+1);
	scanf("%d",&v[c]);
}
for (c=4;c<=4;c--){
	printf ("%d",v[c]);
	
	
}
return(0);
}
